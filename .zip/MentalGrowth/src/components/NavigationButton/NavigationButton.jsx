// libs
import React from "react";

// styles
import stylesCSS from "./styles.scss";

export const NavigationButton = ({ imgUrl, label, bactive }) => {
    return (
        <button type="button" className={[stylesCSS.button, bactive ? stylesCSS.active : ''].join(' ')}>
            <img src={imgUrl}/>
            <span>{ label }</span>
        </button>
    );
};