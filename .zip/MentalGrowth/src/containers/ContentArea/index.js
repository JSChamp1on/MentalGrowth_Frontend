/**
 * Hub file
 */

export { ContentArea } from "./ContentArea";