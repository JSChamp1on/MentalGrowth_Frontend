// libs
import React from "react";

// styles
import stylesCSS from "./styles.scss";

// app
import { constants as constants_app } from "@app";

// images
import logoSVG from "@images/logo.svg";
import trainingSVG from "@images/training.svg";
import discoverSVG from "@images/discover.svg";
import dietSVG from "@images/diet.svg";

// components
import { NavLink } from "@components/NavLink";
import { NavigationButton } from "@components/NavigationButton";

// constants
const {
    HOMEPAGE,
    DISCOVER,
    DIET,
} = constants_app;

export const NavigationPanel = (readonlyProps) => {
    const {
        className: classNameHOK,
    } = readonlyProps;

    return (
        <div className={[classNameHOK, stylesCSS.navBlock].join(' ')}>
            <NavLink to={HOMEPAGE.PATH} className={stylesCSS.logoLink}>
                <img src={logoSVG} alt="Amazing App"/>
            </NavLink>

            <nav className={stylesCSS.nav}>
                <li>
                    <NavLink to={HOMEPAGE.PATH}>
                        <NavigationButton imgUrl={trainingSVG} label={HOMEPAGE.LABEL}/>
                    </NavLink>
                </li>
                <li>
                    <NavLink to={DISCOVER.PATH}>
                        <NavigationButton imgUrl={discoverSVG} label={DISCOVER.LABEL}/>
                    </NavLink>
                </li>
                <li>
                    <NavLink to={DIET.PATH}>
                        <NavigationButton imgUrl={dietSVG} label={DIET.LABEL}/>
                    </NavLink>
                </li>
            </nav>
        </div>
    );
};