// libs
import React from "react";

export const Diet_ = () => {
    return (
        <h1>Diet</h1>
    )
};