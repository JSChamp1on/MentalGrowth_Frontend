/**
 * Hub file
 */

export { Diet_ as Diet } from "./Diet";