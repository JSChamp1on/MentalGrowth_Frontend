// libs
import React from "react";

// styles
import stylesCSS from "./styles.scss";

// containers
import { NavigationPanel } from "@containers/NavigationPanel";
import { ContentArea } from "@containers/ContentArea/ContentArea";

export const Discover = () => {
    return (
        <div className={stylesCSS.wrapper}>
            <NavigationPanel className={stylesCSS.navigationPanel}/>
            <ContentArea className={stylesCSS.contentArea}>
                <h1>Discover</h1>
                <span>Test</span>
            </ContentArea>
        </div>
    )
};