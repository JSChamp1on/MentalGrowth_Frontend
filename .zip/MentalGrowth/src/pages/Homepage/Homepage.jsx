// libs
import React, { useEffect } from "react";

// styles
import stylesCSS from "./styles.scss";

// containers
import { NavigationPanel } from "@containers/NavigationPanel";
import { ContentArea } from "@containers/ContentArea/ContentArea";

export const Homepage = (readonlyProps) => {
    useEffect(() => {
        readonlyProps.actionMgTest.call(readonlyProps);
    }, []);

    return (
        <div className={stylesCSS.wrapper}>
            <NavigationPanel className={stylesCSS.navigationPanel}/>
            <ContentArea className={stylesCSS.contentArea}>
                <h1>Homepage</h1>
                <span>{ 123 }</span>
            </ContentArea>
        </div>
    );
};