// libs
import React from "react";

export const NotFound = () => <h1>404 NotFound</h1>;