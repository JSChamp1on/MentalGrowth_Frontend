/**
 * Hub file
 */

export { NotFound } from "./NotFound";