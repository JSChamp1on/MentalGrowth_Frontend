// redux
import { constants } from "@redux";

// hardcode
import data from "./response";

// constants
const {
    METHOD_MGTEST,
} = constants;
const URL = 'https://d3hhim2ddjqlcy.cloudfront.net/media/custom_file/6f1abf6e-3e7d-48b9-8ec9-995891be310a/MG_test.json';

export const actionMgTest = () => dispatch => {

    fetch(URL, {
        headers: {
            "Access-Control-Allow-Origin": "Origin, X-Requested-With, Content-Type, Accept",
        },
    }).then(console.log);
    
    
    // dispatch({ type: METHOD_MGTEST, payload: { ...payload } });
}