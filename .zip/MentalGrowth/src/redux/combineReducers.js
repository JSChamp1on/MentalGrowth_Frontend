// libs 
import { combineReducers as combineReducers_ } from "redux";

// redux
import { reducers } from "@redux";

export const combineReducers = combineReducers_(reducers);